# phpnuxbill-Internet-speedtest-plugin
 The PHPNuxBill Internet Speedtest plugin is designed to provide users with an easy and efficient way to measure their internet connection speed directly through the PHPNuxBill interface. This feature integrates seamlessly into the PHPNuxBill system, offering a user-friendly experience while maintaining the robust functionality PHPNuxBill is known for.



# Installation


Copy **speedtest.php**, **speedtest.js** and **speedtest_worker.js** folder to folder system/plugin/

Copy **everything .tpl** in ui folder to folder system/plugin/ui/